import React, {useEffect, useRef, useState} from 'react';
import './App.css';
import { Button, TextField, Tooltip } from '@mui/material';
import * as d3 from 'd3'
import * as TreeGen from "tree-json-generator";
import {getRootFromData,getLabelFromData ,Tree} from './Tree'

function App() {

  const alpha = ['a' , 'b', 'c', 'd', 'e', 'f', 'g','h','i']
  const [levels, setLevels] =  useState(4)
  const [nodesPerLevel, setNodesPerLevel] = useState(3)
  const currentSvg = useRef(null);
  const [r, setR] = useState(1);
  const [treeDataState, setTreeDataState] = useState(null);
  const [NRR, setNRR] = useState([]);
  const [globalData, setGlobalData] = useState([])
  const [chunks, setChunks] = useState([])

  const [probe, setProbe] = useState({})
  const [target, setTarget] = useState({})
  const [traceRoute, setTraceRoute] = useState([])


  // find node. BFS or DFS
  const dfs = function (start, nodeLabel) {
    //console.log("Visiting Node " + start.name);
    if (start.label === nodeLabel) {
        // We have found the goal node we we're searching for
        //console.log("Found the node we're looking for!");
        //start.calls += 1
        return start;
    }

    // Recurse with all children
    for (var i = 0; i < start.children?.length; i++) {
        var result = dfs(start.children[i], nodeLabel);
        if (result != null) {
            // We've found the goal node while going down that child
            //result.calls +=1
            return result;
        }
    }

    // We've gone through all children and not found the goal node
    // console.log("Went through all children of " + start.name + ", returning to it's parent.");
    return null;
  }

  const doTraceRoute = (probe, target, initTrace = []) => {
    //const result = dfs(probe.entry, target.entry )
    const trace = initTrace
    //console.log(target.label, probe)
    var current = target
    while(current && probe.data.id !== current.data.id){
      trace.push(current.data.id)
      current = current.parent
    }
    if (trace.length > 0){
      trace.push(probe.data.id)
    }
    //console.log(trace)
    setTraceRoute(trace)
  }
  const doSearch = () => {

      //console.log(probe, target)
      const currentControlIndex = getControlIndex(probe.entry, probe.chunkIdx, probe.itemIdx)
      const currControlIndex = JSON.parse(currentControlIndex)
      if(currControlIndex[0].LAST >= target.entry.label){
        // search pointers here.
        //console.log('will trace pointers')
        doTraceRoute(probe.entry, target.entry,[])
      } else {
        var nextControlIndex = getControlIndex(chunks[probe.chunkIdx+1][1], probe.chunkIdx+1, 1 )
        var nxtControlIndex = JSON.parse(nextControlIndex)
        if(nxtControlIndex[0].LAST >= target.entry.label){
          doTraceRoute(chunks[probe.chunkIdx+1][1], target.entry,[probe.entry.data.id])
        }
        else{
          var nextControlIndex = getControlIndex(chunks[probe.chunkIdx+2][1], probe.chunkIdx+2, 1 )
          var nxtControlIndex = JSON.parse(nextControlIndex)
        if(nxtControlIndex[0].LAST >= target.entry.label){
          doTraceRoute(chunks[probe.chunkIdx+2][1], target.entry,[probe.entry.data.id])
        }
        }
      }

  }

  const setItem = (entry, chunkIdx, itemIdx) => {
    //if(entry.label.substring(0,1) === 'd'){
    if(entry.children === undefined){
      setTarget({entry, chunkIdx, itemIdx})
    }else{
      setProbe({entry, chunkIdx, itemIdx})
    }
  }

  const getTotalNodeSoFar = (depth) => {
    return depth === 0 ? 0 : nodesPerLevel ** depth + getTotalNodeSoFar(depth-1)
}
  const getNameForI = (d,i) => {

    return alpha[d.depth-1]+ (-1*(i - getTotalNodeSoFar(d.depth) - 1))
  } 
  const generateTree = () => {

    const config = {
      node: { // Node fields, required
        id: "@id()", // Pipes
        parent: "@parent()",
        level: "@level()",
        label: "@randomInteger(111111,333333)", 
        name: "@randomInteger(111111,333333)", 
        children: "@child()", // Child field pointer (not required, if children are not needed)
      },
      rootNodesNumber: 1, // Number of root nodes
      childNodesNumber: [nodesPerLevel, nodesPerLevel], // Number of children nodes (from 2 to 5)
      hasChildRate: 1, // Probability of children
      maxLevel: levels // Max nesting




    }


    
 
    let treeData = TreeGen.generate(config);
    treeData[0].parent = null
    const tree = Tree(treeData[0], {label: (data, d, i) => i === 0 ? 'I' : getNameForI(d,i)})  
    if(currentSvg.current){
      currentSvg.current.innerHTML=""
      currentSvg.current.appendChild(tree)
    }
    setTreeDataState(treeData[0]);
  }

  const getAllNodes = (node, nodes = []) => {
    nodes.push(node);
  
    if (node.children) {
      for (const child of node.children) {
        getAllNodes(child, nodes);
      }
    }
  
    return nodes;
  }

  const getMostRecentDataIndex = (chunk, index) => {
    while(index != 0){
      if (!chunk[index].children){
        return index
      }else{
        index--
      }
    }
    return -1
  }

  const getControlIndex = (entry, chunkIndex, entryIdx) =>{
    const controlIndexArray =[]
    if (!entry.data.children)
      return "NA"
    else if(entry.label === "I"){
      if (!(chunkIndex === 0 && entryIdx === 0)){
        controlIndexArray.push({LAST: chunks[chunkIndex-1][chunks[chunkIndex-1].length-1].label, NEXT: 'begin'})  
      }else{
        controlIndexArray.push("EMPTY")
      }
    }
    else {
        controlIndexArray.push(
                  {LAST: chunks[chunkIndex][chunks[chunkIndex].length-1].label, NEXT: 'I_'+(chunkIndex+2)}
        )

        const dataIndex = getMostRecentDataIndex(chunks[chunkIndex],entryIdx)
        
        if (!(dataIndex < 0))
          controlIndexArray.push(
            {LAST: chunks[chunkIndex][dataIndex].label, NEXT: 'begin'})
        else if(chunkIndex !== 0)
          controlIndexArray.push({LAST: chunks[chunkIndex-1][chunks[chunkIndex-1].length-1].label, NEXT: 'begin'})  
        else
          controlIndexArray.push({LAST: 'NONE', NEXT: 'NONE'})
        //console.log(rownum)
        // console.log(globalData[rownum][indexInRow])

        //controlIndexArray.push({LAST: globalData[rownum][indexInRow][globalData[rownum][indexInRow].length -1].label, NEXT: 'I'+(parseInt(entry.label.substring(1))+1)})
        //globalData[]
      
    }
    return JSON.stringify(controlIndexArray)
  }

  const Rep = (label,descendantsWithLabels) => {
    let node = null;
    const pathToRoot = [];
    descendantsWithLabels.forEach((d) => {
      if (d.label === label) {
        node = d;
      }
    });
    if (node) {
      let currentNode = node;
      while (currentNode.parent) {
        currentNode = currentNode.parent;
        const tmp =  descendantsWithLabels.filter(d=> d.data.id == currentNode.id)
        pathToRoot.push(tmp.label);
      }
    }
    // Do something with the node and pathToRoot
    console.log(pathToRoot);
  };
  const splitTree = (r) => {

   
    //get tree
    const root = getRootFromData(treeDataState)
    //var allNodes = getAllNodes(root)

    // console.log("root",root)

    const labels = getLabelFromData(treeDataState, {label: (data, d, i) => i === 0 ? 'I' : getNameForI(d,i)})
    //console.log("labels",labels)
   var descendantsWithLabels =  root.descendants().map((data,i)=> ({...data,label:labels[i]}))
   // console.log("desc",descendantsWithLabels)

     // Divide the tree into replicated and non-replicated parts
     
  const replicatedNodes =  descendantsWithLabels.filter(d => d.depth <= r)
  const nonReplicatedNodes =  descendantsWithLabels.filter(d => d.depth > r)

  const nonReplicatedRoots =  descendantsWithLabels.filter(d=> d.depth == r+1)
  //console.log("hi",nonReplicatedRoot)
  var labelsNRR = nonReplicatedRoots.map(d => d.label);
  labelsNRR.reverse()
  setNRR( labelsNRR );

  const isRootLCA = (node1, node2) => {
      return !(node1.parent == node2.parent)
  }

  const getRep = (node) => {
    const labelstr = node.label.substring(0,1)
    const num = parseInt(node.label.substring(1))
    var isRootLCAFlag = false
    if (num > 1){
      const minusonenode = descendantsWithLabels.filter(d => d.label === labelstr + (num-1))[0]
      isRootLCAFlag  = isRootLCA(node, minusonenode)  
    }

    var returnArray = []
    var current = node.parent
    while(current.parent !== null){
      returnArray.push(current)
      current = current.parent
    }
    returnArray.push(current)
    returnArray.reverse()

    returnArray = returnArray.map(entry => descendantsWithLabels.filter(d => d.data.id === entry.data.id)[0])
    // remove root if its not LCA
    if (!isRootLCAFlag && num > 1)
      returnArray = returnArray.filter(entry => entry.label !== 'I')
    return returnArray
  }

  const getIndexArray = (node) => {
    var returnArray = []
    node.children?.forEach((entry) => {
      returnArray.push(getIndexArray(entry))
    })
    returnArray.push(node)
    returnArray =  returnArray.flat()
    returnArray = returnArray.filter(entry => entry.children !== undefined)
    returnArray = returnArray.map(entry => descendantsWithLabels.filter(d => d.data.id === entry.data.id)[0])
    
    return returnArray
  }

  const getData = (node) => {
    var returnArray = []
    returnArray.push(node)
    node.children?.forEach((entry) => {
      returnArray.push(getData(entry))
    })
    returnArray =  returnArray.flat()
    returnArray = returnArray.filter(entry => entry.children === undefined)
    returnArray = returnArray.map(entry => descendantsWithLabels.filter(d => d.data.id === entry.data.id)[0])
    return returnArray
  }
  
  var gloablData = []
  nonReplicatedRoots.forEach((nrr) => {
    const row = []
    const repArray = getRep(nrr)
    const indexArray = getIndexArray(nrr)
    const data = getData(nrr)
    indexArray.reverse()
    data.reverse()
    row.push(repArray)
    row.push(indexArray)
    row.push(data)
    gloablData.push(row)
  })
  //console.log(gloablData)
  //globalData.reverse()
  gloablData = gloablData.toReversed()
  
  const flattened = gloablData.flat(4)
  const chunkSize = flattened.length/3
  const chunksT = []
  for (let i = 0; i < flattened.length; i += chunkSize) {
    const chunk = flattened.slice(i, i + chunkSize);
    // do whatever
    chunksT.push(chunk)
  }
  setChunks(chunksT)
  setGlobalData(gloablData)
  // console.log(gloablData.flat(4).map(entry => entry.label))
  
  //console.log("NRR",NRR)


  
  
   
    // console.log("replicated", replicatedNodes);
    // console.log("nonreplicated", nonReplicatedNodes);
   
     // Return an array containing the replicated and non-replicated nodes
     return [replicatedNodes, nonReplicatedNodes];
   };
   useEffect(() => {
  
  }, [NRR]);

  return (
    <div  style={{"margin":"20px", "gap": "30px", width:"90%"}}>
      <div style={{"margin":"20px", "gap": "30px"}}>
        <TextField type={"number"} 
                   label="Number of nodes per level"
                   value={nodesPerLevel}
                   onChange={(e) => setNodesPerLevel(parseInt(e.target.value))}
                  >
        </TextField>
      </div>
      <div style={{"margin":"20px", "gap": "30px"}}>
        <TextField type={"number"} 
                   label="Number of levels"
                   value={levels}
                   onChange={(e) => setLevels(parseInt(e.target.value))}
                   >
        </TextField>
      </div>
      <div style={{"margin":"20px", "gap": "30px"}}>
        <Button variant='contained' color='primary' onClick={() => generateTree()}>Generate Index Tree</Button>
      </div>
      <div style={{ margin: "20px", gap: "30px" }}>
        <TextField type={"number"} label="R value" value={r} onChange={(e) => setR(parseInt(e.target.value))}></TextField>
      </div>
      <div style={{"margin":"20px", "gap": "30px"}}>
        <Button variant='contained' color='primary' onClick={() => splitTree(r)}>Split</Button>
        <div>
    NRR {NRR.map((label, index) => (
     <Button  key={index}>{label}</Button>
  ))}
  {
    <>
    {
      NRR.map((label, index) => (
        <div>
        <Button  key={index}>{label}</Button>
        <TextField value={globalData[index][0].map(entry => entry.label)} disabled> </TextField>
        <TextField value={globalData[index][1].map(entry => entry.label)} disabled> </TextField>
        <TextField value={globalData[index][2].map(entry => entry.label)} disabled></TextField>
        </div>
      ))
    }
    </>
  }
  {/* {
    globalData.flat(4).map((entry,index) => <Tooltip title={`Control Index:${getControlIndex(entry, index)}`}><Button>{entry.label}</Button></Tooltip>)
  } */}
  <div>
    <TextField value={probe.entry?.label}  disabled></TextField>
    <TextField value={target.entry?.label} disabled></TextField>
    <Button variant='contained' color='primary' onClick={() => doSearch()}>SEARCH</Button>
    <Button variant='contained' color='primary' onClick={() => setTraceRoute([])}>RESET</Button>
  </div>
  {
    chunks.map((chunk, chunkIndex) => <div>{chunk.map((entry, entryIdx) =><Tooltip title={`Control Index:${getControlIndex(entry, chunkIndex, entryIdx)}`}><Button onClick={() => setItem(entry, chunkIndex, entryIdx)} variant={traceRoute.filter(tr => tr === entry.data.id).length === 0 ? 'outlined' : 'contained'}>{entry.label}</Button></Tooltip>)}</div>)
  }
</div>
      </div>

      <div style={{height:"2000px", width:"2000px", overflowY: "auto"}} id="divid" ref={currentSvg}>
      </div>
    </div>

  );
}

export default App;
